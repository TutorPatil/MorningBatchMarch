package com.corejava.finalsession;

public class TestAccessControllers {

	public static void main(String[] args) {

		System.out.println(Outer.outerName);

	}

}
