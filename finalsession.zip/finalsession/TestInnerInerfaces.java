package com.corejava.finalsession;

public class TestInnerInerfaces {

	public static void main(String[] args) {
		
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://google.com");
		System.out.println(driver.getTitle());
		driver.close();
		driver.manage().maximize();

		
		driver.setTime().implicitlyWait();
		
		
		String s = "selenium";
		s.toLowerCase().length();
	}

}
