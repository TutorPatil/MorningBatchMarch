package com.corejava.finalsession;
import java.util.*;

public class ComparatorEx {

	public static void main(String[] args) {		
		collectionsEx1();

	}
	
	public static void collectionsEx1()
	{
		List<String> al = new ArrayList<String>();
						
		al.add("java");
		al.add("selenium");
		al.add("automation");
		
		
		System.out.println(al);	
		
		Collections.sort(al);
		System.out.println(al);	
		
		Mobile m1 = new Mobile(3, "Black", 8000.50);
		Mobile m2 = new Mobile(2, "White", 6500.80);
		Mobile m3 = new Mobile(3, "Red", 1000.20);
		Mobile m4 = new Mobile(5, "Gray", 15000.50);		
		
		
		List<Mobile> alMobile = new ArrayList<Mobile>();
		
		alMobile.add(m1);
		alMobile.add(m2);
		alMobile.add(m3);
		alMobile.add(m4);
		
		System.out.println(alMobile);
		
		Collections.sort(alMobile,new Comparator<Mobile>() {
			
			public int compare(Mobile m1, Mobile m2) {
				
				if(m1.memory > m2.memory)		
					return -1;
				else if(m1.memory < m2.memory)
					return 1;
				else
					return 0;
			}
		});
		
		
		System.out.println(alMobile);	

	}
	
}
