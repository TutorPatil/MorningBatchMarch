package com.corejava.finalsession;

public class Mobile {
	
	int memory;	
	String colour;
	double cost;
	
	public Mobile(int memory, String colour,double cost) {
		super();
		this.memory = memory;
		this.colour = colour;
		this.cost = cost;
	}
	
	
	public String toString()
	{
		return memory+"  "+colour+"  "+cost;
	}
	
	
	public boolean equals(Object obj)
	{
		Mobile m1 = (Mobile)obj;
		
		if( this.memory == m1.memory)
			return true;
		else
			return false;		
		
	}
	
	

	
}
