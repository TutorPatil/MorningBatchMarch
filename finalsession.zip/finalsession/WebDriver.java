package com.corejava.finalsession;

public interface WebDriver {
	
	void get(String url);
	
	void close();
	
	String getTitle();
	
	Window manage();
	
	TimeOut setTime();
	
	public static void getCurrentUrl()
	{
		System.out.println("Returning the URL...");
	}
	
	
	interface Window{
		
		void maximize();
		
		
	}
	
	
	interface TimeOut{
		
		void implicitlyWait();
		
		void SetTimeOut();
	}
	
	static interface Alert
	{
		void test();
	}

}
