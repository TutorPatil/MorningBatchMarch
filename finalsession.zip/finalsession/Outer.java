package com.corejava.finalsession;
public class Outer {
	
	
	int outerAge = 20;	
	protected static String outerName = "Ramu";
	
	public void printOuterAge()
	{
		System.out.println(outerAge);
		Inner in = new Inner();
		System.out.println(in.innerAge);
		
		InnerPrivate pvt = new InnerPrivate();
		pvt.printPrivateAge();
		
	}		
	class Inner {		
		int innerAge = 10;		
		public void printInnerAge()
		{	System.out.println(innerAge);
			System.out.println(outerAge);
			}			
	}	
	private class InnerPrivate{
		
		private int innerPrivateAge = 5;
		
		private void printPrivateAge()
		{
			System.out.println(innerPrivateAge);
			System.out.println(outerAge);		}		
	}	
	static class InnerStatic{
		static int innerStaticAge = 4;	
		
		String innerStaticName = "Shamu";
		public static void printInnerStaticAge()
		{
			System.out.println(innerStaticAge);
			System.out.println(outerName);
		}
		
		
		
	}

}
