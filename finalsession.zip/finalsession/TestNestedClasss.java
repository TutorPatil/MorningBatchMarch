package com.corejava.finalsession;

public class TestNestedClasss {

	public static void main(String[] args) {
	
		Outer out = new Outer();
		out.printOuterAge();
		
		// Creating object of the inner class outside of its outer class
		Outer.Inner in = out.new Inner();
		in.printInnerAge();
		
		
		
		Outer.InnerStatic inStatic = new Outer.InnerStatic();
		inStatic.printInnerStaticAge();
		System.out.println(inStatic.innerStaticName);
		
		Outer.InnerStatic.printInnerStaticAge();

	}

}
