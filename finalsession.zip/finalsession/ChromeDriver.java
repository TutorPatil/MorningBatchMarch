package com.corejava.finalsession;

public class ChromeDriver implements WebDriver, WebDriver.TimeOut{

	
	public void get(String url) {	
		System.out.println("Navigating to the URL.."+url);		
	}

		public void close() {
			System.out.println("Closing the browser");		
	}

	public String getTitle() {
		return "Page Title";
	}

	public Window manage() {
		
		WebDriver.Window ww = new WebDriver.Window() {			
			
			public void maximize() {
				System.out.println("maximizing the windiow....");
				
			}
		};
		return ww;
	}

	
	public void implicitlyWait() {
		System.out.println("Implictly waiting.....");
		
	}

	public void SetTimeOut() {
		System.out.println("Setting the timeout...");
		
	}

	@Override
	public TimeOut setTime() {
		// TODO Auto-generated method stub
		return null;
	}
	
	

}
