package com.corejava.inheritance;


public class Bike extends Vehicle{
	
	boolean helmetHolder;
	int noOfStands ;
	String chainType ;
	
	
	public void kickStartBike()
	{

		System.out.println("The Bike of the colour -"+colour +
		" which has wheels "+noOfWheels + " of the fuel type +"
		+ fuelType +" which is automatic "+ isAutomatic + "whihc has no helmet Holder "+helmetHolder +
		"which has " + noOfStands +" stands " + "has the chain type of "+ chainType +" Needs a kick start");
	
	}
	
	public void parkVehicle()
	{
		System.out.println(" The bike can be parked using its side stand .....");
	}

}
