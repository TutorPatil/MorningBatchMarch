package com.corejava.inheritance;

public class Car extends Vehicle{
	
	int noOfWipers ;
	boolean needsHelmetForDriving;
	String seatBeltColour ;
	int noOfWheels;
	
	public void setNoOfWheelsToParent(int wheels)
	{
		super.noOfWheels = wheels;
	}
	
	
	public void reverseDrive()
	{
			System.out.println("The Car of the colour -"+colour +
			" which has wheels "+noOfWheels + " of the fuel type +"
			+ fuelType +" which is automatic "+ isAutomatic + "whihc has no of Wipers "+noOfWipers +
			"which needs helmet for driving "+needsHelmetForDriving +" which has a seat belt of the colour+"
			+ seatBeltColour +" can be driven in the reverse direction....");
		
	}
	
	public void parkVehicle()
	{
		System.out.println("The Car of the colour -"+colour +
		" which has wheels "+noOfWheels + " of the fuel type +"
		+ fuelType +" which is automatic "+ isAutomatic + "whihc has no of Wipers "+noOfWipers +
		"which needs helmet for driving "+needsHelmetForDriving +" which has a seat belt of the colour+"
		+ seatBeltColour +" needs more space for parking and the rear camara can be used while parking....");
		System.out.println("===========");
		super.parkVehicle();
	}
	

}
