package com.corejava.inheritance;

public class Vehicle {
	
	String colour;
	int noOfWheels;
	String fuelType;
	boolean isAutomatic; 
	
	
	public void drive()
	{
		System.out.println("The vehicle of the colour -"+colour +
			" which has wheels "+noOfWheels + " of the fuel type +"
			+ fuelType +" which is automatic "+ isAutomatic +" is been driven");
	}
	
	public void parkVehicle()
	{
		System.out.println("The vehicle of the colour -"+colour +
				" which has wheels "+noOfWheels + " of the fuel type +"
				+ fuelType +" which is automatic "+ isAutomatic +" can be parked....");
	}


}
