package com.corejava.inheritance;

public class Car extends Vehicle{
	
	int noOfWipers ;
	boolean needsHelmetForDriving;
	String seatBeltColour ;
	int noOfWheels;
	
	
	public Car(String colour, int noOfWheels, String fuelType, boolean isAutomatic, int noOfWipers,
			boolean needsHelmetForDriving, String seatBeltColour, int noOfWheels2) {
		super(colour, noOfWheels, fuelType, isAutomatic);
		
		this.noOfWipers = noOfWipers;
		this.needsHelmetForDriving = needsHelmetForDriving;
		this.seatBeltColour = seatBeltColour;
		noOfWheels = noOfWheels2;
	}
	
	




	public void setNoOfWheelsToParent(int wheels)
	{
		super.noOfWheels = wheels;
		System.out.println(noOfWheels);
	}
	
	
	


	public void reverseDrive()
	{
			System.out.println("The Car of the colour -"+colour +
			" which has wheels "+noOfWheels + " of the fuel type +"
			+ fuelType +" which is automatic "+ isAutomatic + "whihc has no of Wipers "+noOfWipers +
			"which needs helmet for driving "+needsHelmetForDriving +" which has a seat belt of the colour+"
			+ seatBeltColour +" can be driven in the reverse direction....");
		
	}
	
	public   void parkVehicle()
	{
		System.out.println("The Car of the colour -"+colour +
		" which has wheels "+noOfWheels + " of the fuel type +"
		+ fuelType +" which is automatic "+ isAutomatic + "whihc has no of Wipers "+noOfWipers +
		"which needs helmet for driving "+needsHelmetForDriving +" which has a seat belt of the colour+"
		+ seatBeltColour +" needs more space for parking and the rear camara can be used while parking....");
		System.out.println("===========");
		//super.parkVehicle();
	}
	
	public void parkVehicle(int x)
	{
		System.out.println("The Car of the colour -"+colour +
		" which has wheels "+noOfWheels + " of the fuel type +"
		+ fuelType +" which is automatic "+ isAutomatic + "whihc has no of Wipers "+noOfWipers +
		"which needs helmet for driving "+needsHelmetForDriving +" which has a seat belt of the colour+"
		+ seatBeltColour +" needs more space for parking and the rear camara can be used while parking....");
		System.out.println("===========");
		//super.parkVehicle();
	}


	
	public void fillFuel() {
		System.out.println(" Filling the fuel for the car...");
		
	}
	
	
}
