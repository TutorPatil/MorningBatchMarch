package com.corejava.inheritance;

public class TestVehicle {

	public static void main(String[] args) {
		
	Car c = new Car("Black", 4, "Petorl", true, 2, false, "white", 5);
	c.drive();
	c.reverseDrive();
	c.parkVehicle();
	c.parkVehicle(10);
	c.parkVehicle("Car");
		
	}
	
	
	/*
	 * 
	 *  // April 12 Code of Main Method...
		Car marutiCelerio = new Car();
		
		marutiCelerio.colour = "white";
		marutiCelerio.fuelType="petrol";
		marutiCelerio.isAutomatic=true;
		marutiCelerio.noOfWheels=4;
		marutiCelerio.setNoOfWheelsToParent(4);
		marutiCelerio.noOfWipers=2;
		marutiCelerio.seatBeltColour = "black";
		marutiCelerio.needsHelmetForDriving = false;
		
		marutiCelerio.drive();
		marutiCelerio.parkVehicle();
		marutiCelerio.reverseDrive();
		
		
		System.out.println("=====================");
		
		
		Bike hondaActiva = new Bike();
		hondaActiva.colour = "Red";
		hondaActiva.fuelType =" petrol";
		hondaActiva.noOfWheels=2;
		hondaActiva.isAutomatic = false;
		hondaActiva.chainType = "metalic chain";
		hondaActiva.helmetHolder = true;
		hondaActiva.noOfStands = 2;
		
		hondaActiva.drive();
		hondaActiva.parkVehicle();
		hondaActiva.kickStartBike();
		
		System.out.println("++++++++++++++++++++");
		
		Vehicle v1 = new Vehicle();
		v1.colour = "gray";
		v1.drive();
		v1.parkVehicle();
		
	 * 
	 */

}
