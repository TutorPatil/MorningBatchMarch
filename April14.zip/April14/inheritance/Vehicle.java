package com.corejava.inheritance;

public abstract  class Vehicle {
	
	String colour;
	int noOfWheels;
	String fuelType;
	boolean isAutomatic; 
	
	public Vehicle(String colour, int noOfWheels, String fuelType, boolean isAutomatic) {
		
		this.colour = colour;
		this.noOfWheels = noOfWheels;
		this.fuelType = fuelType;
		this.isAutomatic = isAutomatic;
	}
	
	public abstract void fillFuel();
	

	//public  abstract final void drive()   // Illegal combination 
	public  final void drive()
	{
		System.out.println("The vehicle of the colour -"+colour +
			" which has wheels "+noOfWheels + " of the fuel type +"
			+ fuelType +" which is automatic "+ isAutomatic +" is been driven");
	}
	
	public void parkVehicle()
	{
		System.out.println("The vehicle of the colour -"+colour +
				" which has wheels "+noOfWheels + " of the fuel type +"
				+ fuelType +" which is automatic "+ isAutomatic +" can be parked....");
	}
	
	
	public void parkVehicle(String s)
	{
		System.out.println("The vehicle of the colour -"+colour +
				" which has wheels "+noOfWheels + " of the fuel type +"
				+ fuelType +" which is automatic "+ isAutomatic +" can be parked....");
	}


}
