package com.corejava.interfaces;

public class Car implements Vehicle{

	
	public void drive() {	
		System.out.println("The car is been driven");
	}

	
	public void fillFuel() {
		System.out.println("The cars fuel has to be refilled");
		
	}
	
	

}
