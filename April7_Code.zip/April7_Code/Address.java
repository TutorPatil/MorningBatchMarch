package com.corejava.sample;

public class Address {
	
	int flatNo;
	String area;
	String city;
	int pinCode;
	static String country = "India" ;
	
	public String getAddressDetails()
	{
		return ( flatNo +" --- "+area +" --- "+city+" -- "+pinCode+" -- "+country);
	}
	
	public  void println()
	{
		System.out.println("Country is "+ country);
	}
	
	public static void printCountry()
	{
		System.out.println("Country is "+ country);
	}
	
}
