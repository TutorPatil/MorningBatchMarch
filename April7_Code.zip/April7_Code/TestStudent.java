package com.corejava.sample;

public class TestStudent {

	public static void main(String[] args) {
		
		Address a1 = new Address();
		
		a1.flatNo = 420;
		a1.area = "BTM";
		a1.city = "Bangalore";
		a1.pinCode= 560010;
		
		Student s = new Student();
		
		s.name = "Ramu";
		s.fName = "Dasharath";
		s.feeBalalce = 5000;
		s.std = 5;
		//s.a = a1;
		
		Student.a=a1;
				
		s.doHomeWork();
		s.getStudentDetails();
		
		System.out.println(Student.schoolName);		
		System.out.println(Address.country);
		
		System.out.println(s.a.flatNo);
		System.out.println(s.a.city);
		
		System.out.println("+++++++++++");
		
		System.out.println(Student.a.area);
		
		System.out.println(Student.a.country);
		
		Student.a.printCountry();
		
		System.out.println(Student.a.getAddressDetails());
		
		Student.a.println();
		
		System.out.println();
		
		Address a2 = new Address();
		
		a2.flatNo = 520;
		a2.area = "MG Coloney";
		a2.city = "Hyderabad";
		a2.pinCode= 560010;
		
		Student s1 = new Student();
		
		s1.name = "Shamu";
		s1.fName = "Vasudev";
		s1.feeBalalce = 4000;
		s1.std = 4;
		
		s1.a = a2;
		s1.doHomeWork();
		
		s1.getStudentDetails();
		
		System.out.println("*********************");
		
		Student[] sArray = new Student[2];
		
		sArray[0] = s;
		sArray[1] = s1;
		
		for( Student m : sArray)
		{
			m.getStudentDetails();
		}
		
		System.out.println("%%%%%%%%%%%%%%%%%%%%%%%%");
		
		Address[] aArray = {a1,a2};
		
		for(Address m :aArray)
		{
			System.out.println(m.getAddressDetails());
		}
		
		
	}

}
