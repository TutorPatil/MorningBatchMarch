package com.corejava.sample;

public class Wiper {
	
	String colour;
	int length;
	int numberOfUnits;
	
	public void wipeWindows()
	{
		System.out.println("Wiping winodws...");
	}

}
