package com.corejava.sample;

import java.awt.Color;

public class Car {
	
	String colour;
	int gears;
	boolean isAutomatic;
	int engineCapacity;
	String fuelType;
	final static int wheels = 4;
	Wiper w;
	
	public void drive()
	{
		int x = 20;
		//Wiper w1 = null;
		System.out.println(" The car of the colour "+colour +
		"Of the fuel Type "+fuelType +" which has engine Capacity of "+engineCapacity +
		" is been driven....");
		 System.out.println(wheels);
		 //System.out.println(w1.colour);
		
	}
	
	public static void CloseWindows()
	{
		
		System.out.println(" The car which  has "+ wheels + " can close its windows automatically");
		
	}
	
	public void wipeGlass()
	{
		System.out.println("The car of the colour "+colour +
				" has "+w.numberOfUnits +" is of the colour "+w.colour);
				w.wipeWindows();						
	}
	

}
