package com.corejava.exceptions;

public class April23_RecurssionEx {

	public static void main(String[] args) {
		
		System.out.println(findFactorial(5));
	}
	
	public static void printNumbersDesc(int x)
	{
		System.out.print(x+",");
		
		if(x >0 )  // Base Case
			printNumbersDesc(x-1);
		
	}
	
	
	public static void printNumbersAsc(int x)
	{
		
		if(x >0 )  // Base Case
			printNumbersAsc(x-1);
		
		System.out.print(x+",");
		
	}
	
	public static int findFactorial(int num)
	{
		if ( num == 1)
			return 1;
		
		return (num * findFactorial(num-1));
	}
	
	
	
	
	
	
	

}
