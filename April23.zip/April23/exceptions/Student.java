package com.corejava.exceptions;

public class Student {
	
	int age;
	
	public void setAge(int age) throws InvalidAgeException
	{
		if( age <0 || age > 15)
		{
			InvalidAgeException iae = new InvalidAgeException("The age of the student is invalid");
			throw iae;
		
		}
		
		
	}
	
	public static void main(String[] args) throws InvalidAgeException {
		
		Student s = new  Student();
		s.setAge(-1);
		System.out.println("The custom exception was thrown using throw");
		
	}

}
