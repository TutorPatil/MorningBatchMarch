package com.corejava.exceptions;

public class April23_BoxingUnboxing {

	public static void main(String[] args) {
		
		int x = 10;
		
		Integer xObj = new Integer(x);  // Boxing
		
		int y = xObj.intValue();  // Unboxing..
		
		System.out.println(y);
		System.out.println(xObj.doubleValue());	
		
		System.out.println(Integer.MIN_VALUE);
		System.out.println(Integer.MAX_VALUE);
		System.out.println(Integer.max(20, 30));
		int z = 	Integer.parseInt("1234");
		
		System.out.println(z+100);
		
		char c = 'a';
		
		Character cObj = new Character(c);
		char c1 = cObj.charValue();
		
		System.out.println(cObj.TYPE);		
		System.out.println(xObj.TYPE);
		
		
		
		
		
		
		
		
		

	}

}
