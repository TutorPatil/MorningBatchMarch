package com.corejava.collections;

public class TestCalc {

	public static void main(String[] args) {
		
		Calc Kalc = new Calc();
		System.out.println(Kalc.addNumbers(10, 20));
		
		
		

	}

}
