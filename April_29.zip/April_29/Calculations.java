package com.corejava.collections;


public interface Calculations {
	
	public int addNumbers(int x, int y);	
	
}
