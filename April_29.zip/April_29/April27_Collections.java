package com.corejava.collections;

import java.util.*;

public class April27_Collections {

	public static void main(String[] args) {
		printUniqueChas();
	}
	
	
	public static void printUniqueChas()
	{
		Integer y = 25;
		
		String s = "classes";
		
		Set<Character> hSet = new HashSet<Character>();
		
		for( int x=0; x<s.length();x++)
		{
			Character c = s.charAt(x);			
			hSet.add(c);
		}
		
		System.out.println(hSet);
		
		
		
		
		
	}
	
	
	
	public static void setExample1()
	{
		Set<String> hSet = new HashSet<String>();
		
		hSet.add("java");
		hSet.add("selenium");
		hSet.add("testing");
		hSet.add("automation");
		System.out.println(hSet.add("java"));
		
		
		System.out.println(hSet);
		
		System.out.println(hSet.size());
		
		System.out.println(hSet.contains("selenium"));
		
		Set tSet = new TreeSet();
		
		tSet.add("java");
		tSet.add("selenium");
		tSet.add("testing");
		tSet.add("automation");
		tSet.add(25);
		tSet.add(new Mobile(2, "black", 25));
		
		// Throws an Excepion
		System.out.println(tSet);
		
		
		Set tSet1 = new TreeSet();
		
		tSet1.add("java");
		tSet1.add("selenium");
		tSet1.add("testing");
		tSet1.add("automation");
		
		System.out.println(tSet1);
	}
	
	
	
	
	
	
	
	public static void listEx4()
	{
		List<String> al = new ArrayList<String>();		
		
		al.add("selenium");
		al.add("java");
		al.add("automation");
		
		Object[] alArray = al.toArray();
		
		String[] sArray = {"testing","dev","devops"};
		
		System.out.println(Arrays.asList(sArray).contains("testing"));
		
		
		
		
	}
	
	
	public static void listEx3()
	{
		Mobile m1 = new Mobile(3, "Black", 8000.50);
		Mobile m2 = new Mobile(2, "White", 6500.80);
		Mobile m3 = new Mobile(4, "Red", 1000.20);
		Mobile m4 = new Mobile(5, "Gray", 15000.50);
		
		List<Mobile> mList = new ArrayList<Mobile>();
		
		mList.add(m1);
		mList.add(m3);
		mList.add(m4);
		mList.add(m2);
		
		System.out.println(mList.indexOf(m3));
		
		System.out.println(mList);
		
		Object[] mArray = mList.toArray();
		
		System.out.println(mArray.length);
		System.out.println(Arrays.toString(mArray));
		
		
		
	List<Mobile> al2= mList.subList(1, 3);
	
	System.out.println(al2);
		
		for (Mobile m : mList)
		{
			System.out.println(m);
		}
		
	}
	public static void listExample2()
	{
	 
		List<String> al = new ArrayList<String>();		
		
		al.add("selenium");
		al.add("java");
		al.add("automation");
		al.add("selenium");
		al.add(null);
		
		System.out.println(al);		
		System.out.println(al.get(0));		
		System.out.println(al.get(3));		
		System.out.println(al.contains("java"));
		
		System.out.println("===============");
		
		for(int x=0; x<al.size();x++)
		{
			System.out.print(al.get(x)+" ");
		}
		
		// Adds a new Object at the end
		al.add("Manual Testing");
		
		// Inserts the new Object and push the existing objects to right side
		al.add(1, "python");
		
		System.out.println(al);
		
		//Replaces the original object in that index with new Object
		al.set(0, "Webdriver");
		
		System.out.println(al);
		
		
		
		List<String> al2 = new ArrayList<String>();
		
		al2.add("DevOps");
		al2.add("WebServices");
		al2.add("NodeJs");
		
		System.out.println(al2);
		
		al.addAll(al2);
		
		System.out.println(al);
		
		al.removeAll(al2);
		System.out.println(al);
		
		al.addAll(1, al2);
		
		System.out.println(al);
		
	}
	
	
	
	public static void ListEx1()
	{
		
		// Default initial capacity is 10
		//List<String> al = new ArrayList<String>();
		
		List<String> al = new ArrayList<String>(18);		
		List<String> al1 = new ArrayList<String>(al);
		
		al.add("selenium");
		al.add("java");
		al.add("automation");
		al.add("selenium");
		al.add(null);
		
		System.out.println(al.size());
		System.out.println(al);
		
		
		

	}
	
	

}



