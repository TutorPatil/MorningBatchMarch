package com.corejava.collections;

public interface Test {
	
	public String convertToUpperCase(String s);
	

}
