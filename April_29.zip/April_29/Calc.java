package com.corejava.collections;

public class Calc implements Calculations {

	
	public int addNumbers(int x, int y) {		
		return (x+y);		
	}

	
	
	

}
