package com.corejava.collections;

public class CalcLatest {
	
	public static void main(String[] args) {
		
		
		/*
		 * 
		 * Calculations kalc  = new Calculations() {
			
			public int addNumbers(int x, int y) {
				return(x+y);
			}
		};
		 */
		
		//Calculations kalc  = (int x, int y) -> (x+y);
		
//		Calculations kalc  = (x, y) -> (x+y);
//		
//		System.out.println(kalc.addNumbers(20, 30));
		
		
		Calculations kalc = (x, y) -> (x+y);
		
		System.out.println(kalc.addNumbers(10,20));
		
		
		Test t = s -> s.toUpperCase();
		
		System.out.println(t.convertToUpperCase("seelnium"));
		
	}

}
