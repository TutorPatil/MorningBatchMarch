package com.corejava.poly;

public class Bike extends Vehicle{
	
	
	public void kickStartBike()
	{
		System.out.println("The Bike can also be started using the kick...");
	}
	

	public void drive()
	{
		System.out.println("The Bike is been driven...");
	}
	
	public void park()
	{
		System.out.println("The Bike is been parked...");
	}
	

	public void vehicleNoise()
	{
		System.out.println("The Bike is making noise while  driving");
	}


	
}
