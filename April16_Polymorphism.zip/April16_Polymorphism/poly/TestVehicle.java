package com.corejava.poly;

public class TestVehicle {

	public static void main(String[] args) {
/*
		Vehicle v = new Car();
		
		v.drive();
		v.park();
		
		if( v instanceof Car)
		{		
			((Car)v).reverseDrive();
		}
		if(v instanceof Bike)
		{
			((Bike)v).kickStartBike();
		}
		
		byte b = (byte) 150;
		
		Object obj = new Car();
		
		((Car)obj).drive();
		
		int[] x = {1,2,3,4};
		
		Object[] x1 = {1,2,3,4};
		
		String s = "Selenium";
		
		Object s1 = "Selenium";
		
	*/	
		Car car1 = new Car();
		
		Bike b1 = new Bike();
		
		Car.TestVehicleNoise(car1);
		
		Car.TestVehicleNoise(b1);
		
		
		Vehicle v2 = Car.getObject();
		v2.drive();
		
		
		

	}

}
