package com.corejava.poly;

public class Car extends Vehicle {
	
	public void reverseDrive()
	{
		System.out.println("The car can be driven in reverse direction....");
	}
	
	
	public void drive()
	{
		System.out.println("The Car is been driven...");
	}
	
	public void park()
	{
		System.out.println("The Car is been parked...");
	}
	

	public void vehicleNoise()
	{
		System.out.println("The Car is making noise while  driving");
	}

	//public static void TestVehicleNoise(Car c)  // child type as argument
	
	public static void TestVehicleNoise(Object obj)  // Prenttype as argument to get polymorphism
	{	
		Vehicle v1 = (Vehicle)obj;
		v1.vehicleNoise();
	}
	
	public static Vehicle getObject()
	{
		Car c1 = new Car();
		return c1;
		
//		Bike c1 = new Bike();
//		return c1;
	}
	
	
}
