package com.corejava.strings;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;

public class April_21FileHandling {

	public static void main(String[] args) throws IOException {
		
	}
	
	//readDataFromFile();
	public static void readDataFromFile() throws IOException
	{
		File f = new File("D:\\morningBatch\\test.txt");
		
		FileReader fr = new FileReader(f);
		BufferedReader br = new BufferedReader(fr);
		
		String line ="";
		
		while ((line = br.readLine()) != null)
		{
			System.out.println(line);
		}
			
		
		
		
		br.close();
		fr.close();
	
		
		
	}
	
	//writeToHtmlFile();
	public static void writeToHtmlFile() throws IOException
	{
		File f = new File("D:\\morningBatch\\results.html");
		f.createNewFile();
		
		FileWriter fw = new FileWriter(f,true);
		fw.write("<html>");
		
		fw.write("<head>");
			fw.write("<title>LoginPage</title>");		
		fw.write("</head>");		
		fw.write("<body>");
		
		fw.write("UserName<input type='text' id='username' ></input>");
		fw.write("<br>");
		fw.write("Password<input type='text' id='pwd'></input>");
		fw.write("<br>");
		fw.write("<button id='ok' >OK</button>");		
		fw.write("<button id='cancel'>Cancel</button>");
		
		fw.write("</body>");		
		fw.write("</html>");
		
		fw.flush();
		fw.close();	
	}
	
	//writeResultsToFile("Login_004","Fail");		
	public static void writeResultsToFile(String testCaseName, String status) throws IOException
	{
		File f = new File("D:\\morningBatch\\test.txt");		
		FileWriter fw = new FileWriter(f,true);
		fw.write(testCaseName+"---->"+status+"\n");		
		fw.flush();
		fw.close();			
	}
	
	public static void writeToFile() throws IOException
	{
		File f = new File("D:\\morningBatch\\test.txt");			
		
		FileWriter fw = new FileWriter(f,true);
		fw.write("Java seems to be very interesting....\n");
		fw.write("Selenium will be further interesting....\n");
		fw.write("You just need to practice to become a champion....\n");
		
		fw.flush();
		fw.close();
		
				
	}
	
	public static void getDirectoryContents()
	{
		File f = new File("D:\\morningBatch");
		
		f.isDirectory();
		
		String[] fArr = f.list();
		
		System.out.println(Arrays.toString(fArr));
		
	}

}
