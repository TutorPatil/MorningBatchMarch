package com.corejava.strings;

public class April21_Exceptions {

	public static void main(String[] args) {
		
//		int x = 10;
//		int y = 0;
//		
//		int z = x/y;
//		
//		System.out.println(z);
//		
//		int[] a = {1,2,3,4,5};
//		
//		System.out.println(a[10]);

		method1();
	}
	
	public static void method1()
	{
		//System.out.println("Inisde method1");
		int x = 10;		
		method2();
	}
	
	public static void method2()
	{
		//System.out.println("Inisde method2");
		int y = 10;
		method1();
	}


}
