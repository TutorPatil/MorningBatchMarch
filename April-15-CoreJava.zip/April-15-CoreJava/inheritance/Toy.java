package com.corejava.inheritance;

public interface Toy {
	
	public abstract void kidsFriendlyFeature();

}
