package com.corejava.oops;

public class BankAccount {
	
	private int balance = 10000 ;
	private int accountNo = 12345;
	private  String name;
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getBalance() {
		return balance;
	}
	public int getAccountNo() {
		return accountNo;
	}
	
	public void withdrawAmount(int amt)
	{
		if( amt < balance)
		{
			System.out.println(" please collect your cash of "+amt);
			updateBalanceOnWithDraw(amt);
		}
		else
			System.out.println(" You dont have sufficient balance....");
	}
	
	private void updateBalanceOnWithDraw(int amt)
	{
		balance = (balance - amt);
	}
	
	public void deposit(int amt)
	{
		System.out.println(" Thanks for depositing "+amt );		
		updateBalanceOnDeposit(amt);
	}
	
	private void updateBalanceOnDeposit(int amt)
	{
		balance = (balance + amt);
	}
	
	

}
