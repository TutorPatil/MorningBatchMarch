package com.corejava.oops;

public class Car {
	
	private String colour;
	private int noOfGears ;
	private boolean isAutomatic;
	
	public int getNoOfGears() {
		return noOfGears;
	}
	public void setNoOfGears(int noOfGears) {		
		if( (noOfGears > 3) && (noOfGears < 5))
		{
			this.noOfGears = noOfGears;
		}
	}
	public boolean isAutomatic() {
		return isAutomatic;
	}
	public void setAutomatic(boolean isAutomatic) {
		this.isAutomatic = isAutomatic;
	}
	
	public void setColour(String colour)
	{
		if( (colour != null) && ( colour.equals("Black")))
		{
			this.colour = colour;
		}
		else
		{
			System.out.println("please enter correct value for the color");
		}
	}	
	public String getColour()
	{
		return colour;
	}
	
	public void drive()
	{	
		System.out.println(" The car of the colour "+colour +" which has gears --"+noOfGears
		 + "  which is automatic "+isAutomatic +" is been driven");
	}	
	
	
	public String toString() {
        return colour+" --- "+noOfGears+" --- "+ isAutomatic;
    }
	
	public boolean equals(Object obj) {
		Car c2 = (Car)obj;
		
		if((this.isAutomatic == c2.isAutomatic)
				&& (this.colour.equals(c2.colour)) 
				&& (this.noOfGears == c2.noOfGears) )
		{
			return true;
		}
		else
		{
			return false;
		}
        
    }

}
