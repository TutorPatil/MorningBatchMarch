package com.corejava.oops;

public class TestCar {

	public static void main(String[] args) {
		
		Car c = new Car();
		
		c.setColour("Black");
		c.setAutomatic(true);
		c.setNoOfGears(4);
		
		Car c1 = new Car();
		c1.setColour("White");
		c1.setAutomatic(true);
		c1.setNoOfGears(4);
		
		
		System.out.println(c.getClass());
		
		System.out.println(c.hashCode());
		
		System.out.println(c1.hashCode());
		
		System.out.println(c.toString());
		
		System.out.println(c);
		
		//c=c1;
		
		System.out.println(c.equals(c1));
		
		
//		c=c1;
//		
//		System.out.println(c.hashCode());
//		
//		System.out.println(c1.hashCode());
		
	}

}
