package com.corejava.oops;

public interface Vehicle {
	
	

}
