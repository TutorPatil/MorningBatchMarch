package com.corejava.poly;

public class Car extends Vehicle {
	
	public void reverseDrive()
	{
		System.out.println("The car can be driven in reverse direction....");
	}
	
	
	public void drive()
	{
		System.out.println("The Car is been driven...");
	}
	
	public void park()
	{
		System.out.println("The Car is been parked...");
	}

}
