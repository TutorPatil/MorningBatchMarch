package com.corejava.poly;

public class TestVehicle {

	public static void main(String[] args) {

		Vehicle v = new Car();
		
		v.drive();
		v.park();
		
		if( v instanceof Car)
		{		
			((Car)v).reverseDrive();
		}
		if(v instanceof Bike)
		{
			((Bike)v).kickStartBike();
		}
		
		byte b = (byte) 150;
		
		
		
		

	}

}
