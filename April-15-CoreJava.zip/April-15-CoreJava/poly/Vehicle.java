package com.corejava.poly;

public class Vehicle {
	
	public void drive()
	{
		System.out.println("The vehicle is been driven...");
	}
	
	public void park()
	{
		System.out.println("The vehicle is been parked...");
	}
	

}
