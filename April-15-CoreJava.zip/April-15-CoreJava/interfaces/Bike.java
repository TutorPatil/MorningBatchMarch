package com.corejava.interfaces;

public class Bike implements Vehicle{

	
	public void drive() {
	
		System.out.println("The bike is been driven");
	}

	
	public void fillFuel() {
		System.out.println("The bikes fuel is over pls fill");
		
	}

}
