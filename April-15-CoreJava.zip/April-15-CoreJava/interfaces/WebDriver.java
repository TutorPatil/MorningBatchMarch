package com.corejava.interfaces;

import com.corejava.inheritance.Toy;

public interface WebDriver extends SearchContext,Toy {
	
	public abstract void get(String url);
	
	void closeBrowser();
	
	String getCurrentUrl();
	
	String getTitle();
	
	
	

	

}
