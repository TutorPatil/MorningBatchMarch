package com.corejava.interfaces;

public class FireFoxFriver implements WebDriver{
	

	public void findElement(String s) {
		System.out.println(" FIREFOX--FInding the element for "+s);
		
	}

	
	public String findElements(String[] s) {
		return "FIREFOX--Array Of Elements";
	}

	
	public void get(String url) {
		System.out.println("FIREFOX--loading the page for the URL "+url);
		
	}

	public void closeBrowser() {
		System.out.println("FIREFOX--Closing the browser");
		
	}

	public String getCurrentUrl() {
		return "FIREFOX--The curent Url is -----";
	}

	
	public String getTitle() {
		return "The Title is +++++";
	}
	
	public void kidsFriendlyFeature() {
		System.out.println("Inside the toy method from Firefox browser...");
		
	}

}
