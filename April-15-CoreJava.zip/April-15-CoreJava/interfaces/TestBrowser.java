package com.corejava.interfaces;

public class TestBrowser {

	public static void main(String[] args) {
		String browser = "Firefox";
		WebDriver driver = null;
		
		if(browser.equalsIgnoreCase("chrome"))
		{
			 driver = new ChromeDriver();
		
		}
		else if(browser.equalsIgnoreCase("FireFox"))
		{
			 driver = new FireFoxFriver();
		}
		
		driver.get("https://google.com");
		
		System.out.println(driver.getCurrentUrl());
		
		driver.closeBrowser();
		
		driver.findElement("searchButton");
		
		driver.findElements(new String[] {"java","selenium","automation"});
		
		/*
		 * System.out.println("+++++++++++++++++++++++++");
		 * 
		 * FireFoxFriver fdriver = new FireFoxFriver();
		 * 
		 * fdriver.get("https://google.com");
		 * 
		 * System.out.println(fdriver.getCurrentUrl());
		 * 
		 * fdriver.closeBrowser();
		 * 
		 * fdriver.findElement("searchButton");
		 * 
		 * fdriver.findElements(new String[] {"java","selenium","automation"});
		 */
	}

}
