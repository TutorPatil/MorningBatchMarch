package com.corejava.interfaces;

public interface Vehicle {
	
	public static final int maxSpeed = 100;
	boolean canRunOnRoad = true;
	
		
	public abstract void drive();	
	void  fillFuel();
	
	public static void applyFastTag()
	{
		System.out.println("Your vehicle should have the fast tag..");
	}
	
	
	//public abstract void testFastTag();
	

}
