package com.corejava.interfaces;

public interface SearchContext {
	
	public abstract void findElement(String s);
	
	public abstract String findElements(String[] s);
	
}
