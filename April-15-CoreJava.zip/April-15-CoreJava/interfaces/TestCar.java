package com.corejava.interfaces;

public class TestCar {

	public static void main(String[] args) {
	
		
		Car c = new Car();
		
		c.drive();
		
		System.out.println(Vehicle.canRunOnRoad);
		
		Bike b= new Bike();
		b.drive();
		b.fillFuel();
		
		System.out.println(Vehicle.canRunOnRoad);
		System.out.println(Vehicle.maxSpeed);
		
		Vehicle.applyFastTag();	
		
	}

}
