package com.corejava.oops;

public class TestCar {

	public static void main(String[] args) {
		
//		Car c = new Car();
//		
//		c.setColour("black");
//		c.setNoOfGears(4);
//		c.setAutomatic(true);
//		
//		c.drive();
		
		
		BankAccount b1 = new BankAccount();
		b1.setName("RamKrishna");
		
		System.out.println(b1.getBalance());
		
		b1.deposit(15000);
		
		System.out.println(b1.getBalance());
		
		b1.withdrawAmount(5000);
		
		System.out.println(b1.getBalance());

	}

}
