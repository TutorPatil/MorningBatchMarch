package com.corejava.oops;

public class Car {
	
	private String colour;
	private int noOfGears ;
	private boolean isAutomatic;
	
	public int getNoOfGears() {
		return noOfGears;
	}
	public void setNoOfGears(int noOfGears) {		
		if( (noOfGears > 3) && (noOfGears < 5))
		{
			this.noOfGears = noOfGears;
		}
	}
	public boolean isAutomatic() {
		return isAutomatic;
	}
	public void setAutomatic(boolean isAutomatic) {
		this.isAutomatic = isAutomatic;
	}
	
	public void setColour(String colour)
	{
		if( (colour != null) && ( colour.equals("black")))
		{
			this.colour = colour;
		}
		else
		{
			System.out.println("please enter correct value for the color");
		}
	}	
	public String getColour()
	{
		return colour;
	}
	
	public void drive()
	{	
		System.out.println(" The car of the colour "+colour +" which has gears --"+noOfGears
		 + "  which is automatic "+isAutomatic +" is been driven");
	}	

}
