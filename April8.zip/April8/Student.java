package com.corejava.sample;

public class Student {
	
	String name;
	int std;
	String fName;
	int feeBalalce;
	Address a;
	static String schoolName = "Govt Primary school";
	
	public Student(String name, int std, String fName, int feeBalalce, Address a) {
		
		this.name = name;
		this.std = std;
		this.fName = fName;
		this.feeBalalce = feeBalalce;
		this.a = a;
	}
	
	
	public Student()
	{
		
	}


	
	
	public void doHomeWork()
	{
		System.out.println("The student of the name "+name +" of the class "+
					std +" has submitted his home work");
	}
	
	public void getStudentDetails()
	{
		System.out.println(" Name "+name);
		System.out.println(" std "+std);
		System.out.println(" father's Name "+fName);
		System.out.println(" Fee Balance Details "+feeBalalce);
		System.out.println(a.getAddressDetails());
		
	}

}
