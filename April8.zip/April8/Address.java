package com.corejava.sample;

public class Address {
	
	int flatNo;
	String area;
	String city;
	int pinCode;
	static String country = "India" ;
		
	// Constructor is a method like entity	// Name of the constructor is same as the name of the class	// It may or may not take any arguments	// It wont have any return types	// The default constructor is added by the compiler if its not added by the programer	// It will be invoked by JVM whenever the object/instance of the class is created...	
	
	
	
	public Address(int flatNo,  String city, int pincode)
	{
		this.flatNo = flatNo;		
		this.city = city;
		this.pinCode = pincode;
	}
	

	public Address( String area,int flatNo, int pinCode) {
	
		this.flatNo = flatNo;
		this.area = area;
		this.pinCode = pinCode;
	}






	public Address(int flatNo, String area, String city, int pinCode) {
		
		this.flatNo = flatNo;
		this.area = area;
		this.city = city;
		this.pinCode = pinCode;
	}





	public Address()
	{
		
	}	
	
	
	public String getAddressDetails()
	{
		return ( flatNo +" --- "+area +" --- "+city+" -- "+pinCode+" -- "+country);
	}
	
	public  void println()
	{
		System.out.println("Country is "+ country);
	}
	
	public static void printCountry()
	{
		System.out.println("Country is "+ country);
	}
	
}
