package com.corejava.sample;

public class April8_Constructors {

	public static void main(String[] args) {
		
		Address a1 = new Address(100, "VijayNagar", "Bangalore", 560010);
		
		Student s = new Student("Ramu", 5, "Anand", 5000, a1);
		
		//Address a1 = new Address();
		
		//System.out.println(a.city);
		
		//System.out.println(a.getAddressDetails());
				
		
		//System.out.println(a.pinCode);
		
//		a.flatNo = 122;
//		a.area = "VijayNagar";
//		a.city = "Bangalore";
//		a.pinCode=560010;
//		
		
		
		
	}

}
